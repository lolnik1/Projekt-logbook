Projekt studencki 'Logbook', dla UTP Bydgoszcz.
