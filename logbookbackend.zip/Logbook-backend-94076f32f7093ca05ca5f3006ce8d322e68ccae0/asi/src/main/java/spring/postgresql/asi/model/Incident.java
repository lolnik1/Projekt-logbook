/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spring.postgresql.asi.model;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import java.io.Serializable;
import java.sql.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Informatyka
 */
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "incidents")
public class Incident implements Serializable {

    private static final long serialVersionUID = -3009157732242241606L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name = "type")
    private String type;

    @Column(name = "description")
    private String descr;

    @NotNull
    @Column(name = "isIncidentTemplate")
    private boolean isIncidentTemplate;

    @JsonIgnore
    @JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
    @OneToMany(mappedBy = "incident", cascade = CascadeType.ALL)
    private List<IncidentReport> incidentReport;


    public Incident(String type, String descr, boolean isIncidentTemplete) {
        this.type = type;
        this.descr = descr;
        this.isIncidentTemplate = isIncidentTemplete;
    }

    public Incident(String type, boolean isIncidentTemplate) {
        this.type = type;
        this.isIncidentTemplate = isIncidentTemplate;
    }

    @Override
    public String toString() {
        return String.format("Incident[id=%s, type='%s', desc='%s']", id, type, descr);
    }
}
