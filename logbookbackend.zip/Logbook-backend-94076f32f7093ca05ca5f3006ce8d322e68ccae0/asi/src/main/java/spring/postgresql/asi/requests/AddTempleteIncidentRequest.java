/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spring.postgresql.asi.requests;

import java.sql.Date;
import lombok.Getter;
import lombok.Setter;
import spring.postgresql.asi.model.Incident;

/**
 *
 * @author Informatyka
 */
@Getter
@Setter
public class AddTempleteIncidentRequest {

    private String employeeId;
    private Long incidentId;
    private Date date;
    private String systemId;
}
