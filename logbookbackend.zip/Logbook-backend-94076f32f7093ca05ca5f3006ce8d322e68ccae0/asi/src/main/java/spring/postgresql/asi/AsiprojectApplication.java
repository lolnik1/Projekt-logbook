package spring.postgresql.asi;

import java.util.Collections;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import spring.postgresql.asi.model.Comment;
import spring.postgresql.asi.model.Employee;
import spring.postgresql.asi.model.Incident;
import spring.postgresql.asi.model.IncidentReport;
import spring.postgresql.asi.model.ItSystem;
import spring.postgresql.asi.repo.CommentRepository;
import spring.postgresql.asi.repo.IncidentReportRepository;
import spring.postgresql.asi.repo.IncidentRepository;
import spring.postgresql.asi.repo.EmployeeRepository;
import spring.postgresql.asi.repo.ItSystemRepository;

@SpringBootApplication
public class AsiprojectApplication implements CommandLineRunner {

    @Autowired
    EmployeeRepository employeeRepository;
    @Autowired
    IncidentRepository incidentRepository;
    @Autowired
    IncidentReportRepository incidentReportRepository;
    @Autowired
    ItSystemRepository itSystemRepository;
    @Autowired
    CommentRepository commentRepository;

    public static void main(String[] args) {
        SpringApplication.run(AsiprojectApplication.class, args);
    }

    @Override
    public void run(String... arg0) throws Exception {
        // clear all record if existed before do the tutorial with new data
        incidentRepository.deleteAll();
        employeeRepository.deleteAll();
        commentRepository.deleteAll();
        incidentReportRepository.deleteAll();
        itSystemRepository.deleteAll();
        downloadEmployees();
        downloadSystems();
        initData();

    }

    public void downloadEmployees() throws JSONException, RestClientException {
        String resourceUrl = "http://212.122.192.216:8097/api/v1/employee/all";
        ResponseEntity<String> response = apiResponse(resourceUrl);

        if (response.getStatusCodeValue() == 200) {
            JSONArray json = new JSONArray(response.getBody());

            for (int i = 0; i < json.length(); i++) {

                JSONObject jo = json.getJSONObject(i);

                Object obj = jo.get("function");
                if (obj.getClass().equals(String.class)) {

                    employeeRepository.save(new Employee(
                            jo.getString("employeeId"),
                            jo.getString("name"),
                            jo.getString("function"),
                            jo.getString("email"),
                            jo.getString("login"),
                            jo.getBoolean("isAsi")
                    ));

                } else {

                    employeeRepository.save(new Employee(
                            jo.getString("employeeId"),
                            jo.getString("name"),
                            null,
                            jo.getString("email"),
                            jo.getString("login"),
                            jo.getBoolean("isAsi")
                    ));
                }

//                List<String> employeeIdList = new ArrayList<>();
//                employeeRepository.findAll().forEach(a -> {
//                    employeeIdList.add(a.getId());
//                    System.out.println(a);
//                }
//                );
//                for (int employeeId = 0; employeeId < employeeIdList.size(); employeeId++) {
//                    if (jo.getString("employeeId").equalsIgnoreCase(employeeIdList.get(employeeId))) {
//                        System.out.println("true");
//                    } else {
//                        System.out.println("false");
//                    }
//                }
            }
        } else {
            System.out.println("Employees are not available");
        }

    }

    public ResponseEntity<String> apiResponse(String resourceUrl) throws RestClientException {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        HttpEntity<String> entity = new HttpEntity<>(headers);
        ResponseEntity<String> response = restTemplate.exchange(resourceUrl, HttpMethod.GET, entity, String.class);
        return response;
    }

    public void downloadSystems() throws JSONException, RestClientException {
        String resourceUrl = "http://212.122.192.216:8097/api/v1/itsystem/all";
        ResponseEntity<String> response = apiResponse(resourceUrl);

        if (response.getStatusCodeValue() == 200) {
            JSONArray json = new JSONArray(response.getBody());
            for (int i = 0; i < json.length(); i++) {

                JSONObject jo = json.getJSONObject(i);
                itSystemRepository.save(new ItSystem(
                        jo.getString("id"),
                        jo.getString("name"),
                        jo.getString("description"),
                        jo.getString("administratorId")
                )
                );

            }
        } else {
            System.out.println("Systems are not available");
        }
    }

    private void initData() {
        new Employee("1000004", "Tomasz Tomasik", "Service", "te.te@o2.pl", "asb", false);
        IncidentReport incidentReport1 = new IncidentReport(new Employee("1000000", "Michal Piotrowski", "Admin", "m.piotrowski@gmail.com", "mpot", false), new Incident("Emergency", "long descr", true), new ItSystem("123123","Office Omnom","Office","0131"));
        IncidentReport incidentReport2 = new IncidentReport(new Employee("1000002", "Robert Giza", "NetAdmin", "robi.giza@utp.pl", "mas", true), new Incident("NotImportant", "short descr", false), new ItSystem("0137","Gameroom","Gaming","0131"));
        incidentReportRepository.save(incidentReport1);
        incidentReportRepository.save(incidentReport2);
        Comment comment = new Comment("wczoraj dzisiaj jutro", null, new IncidentReport(new Employee("1ff00002", "Robert Giza", "NetAdmin", "robi.giza@utp.pl", "mas", true), new Incident("NotImportant", "short descr", false), new ItSystem("0138","Serwer","It system","0134")));
        commentRepository.save(comment);

    }
}
