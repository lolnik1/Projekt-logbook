/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spring.postgresql.asi.controller;

import java.sql.Date;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import spring.postgresql.asi.model.Incident;
import spring.postgresql.asi.repo.IncidentRepository;

/**
 *
 * @author Informatyka
 */
@RestController
public class IncidentController {

    @Autowired
    IncidentRepository repository;

    /*
    @RequestMapping("/incident/save")
    public String process() {
        Date date = new Date(0);
        // save a list of incidents
        repository.save(Arrays.asList(new Incident("Normal", "Cleaning data", true), new Incident("Not important", "Adding new user", false),
                new Incident("Normal", "Buying new computer to class", false), new Incident("Emergency", "Problem with server", true)));

        return "Done";
    }
*/

    @PostMapping("/incident")
    public void saveIncident(@RequestBody Incident incident) {
        repository.save(incident);
    }

    @GetMapping("/incidents")
    public List<Incident> findAll() {
        return (List<Incident>) repository.findAll();
    }
    
    @GetMapping("/incident/templates")
    public List<Incident> findAllTemplates() {
        List<Incident> list = (List<Incident>) repository.findAll();
        return list.stream()
                .distinct()
                .filter(incident -> Objects.equals(true, incident.isIncidentTemplate()))
                .collect(Collectors.toList());
    }

    @GetMapping("/incident/id={id}")
    public Incident findById(@PathVariable("id") long id) {
        return repository.findOne(id);
    }

    @GetMapping("/incident/type={type}")
    public List<Incident> fetchDataByName(@PathVariable("type") String type) {
        return repository.findByType(type);
    }
}
