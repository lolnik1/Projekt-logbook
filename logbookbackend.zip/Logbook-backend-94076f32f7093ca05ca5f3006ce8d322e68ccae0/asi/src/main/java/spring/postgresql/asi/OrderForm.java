/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spring.postgresql.asi;

import com.vaadin.ui.Button;
import com.vaadin.ui.DateField;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.TextField;
import spring.postgresql.asi.repo.IncidentReportRepository;
import spring.postgresql.asi.repo.IncidentRepository;
import spring.postgresql.asi.repo.EmployeeRepository;

/**
 *
 * @author Informatyka
 */
public class OrderForm extends FormLayout{
   
    private TextField quantity = new TextField("a");
    private DateField date = new DateField("e");
    private Button newButton = new Button("u");


    private IncidentReportRepository incidentReportRepository;
    private IncidentRepository incidentRepository;
    private EmployeeRepository employeeRepository;
    
    private VaadinUI vaadinUI;
   

    public OrderForm(IncidentReportRepository incidentReportRepository, EmployeeRepository employeeRepository,
            IncidentRepository incidentRepository, VaadinUI vaadinUI) {
    }
    
}
