/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spring.postgresql.asi;

import com.vaadin.server.VaadinRequest;
import com.vaadin.spring.annotation.SpringUI;
import com.vaadin.ui.Button;
import com.vaadin.ui.Grid;
import com.vaadin.ui.Grid.Column;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import spring.postgresql.asi.model.Incident;
import spring.postgresql.asi.model.IncidentReport;
import spring.postgresql.asi.model.Employee;
import spring.postgresql.asi.repo.IncidentReportRepository;
import spring.postgresql.asi.repo.IncidentRepository;
import spring.postgresql.asi.repo.EmployeeRepository;

@SpringUI
public class VaadinUI extends UI {

    @Autowired
    private IncidentRepository incidentRepository;
    @Autowired
    private IncidentReportRepository incidentReportRepository;
    @Autowired
    private EmployeeRepository employeeRepository;

    private Grid<IncidentReport> incidentReportGrid = new Grid<>(IncidentReport.class);
    private OrderForm orderForm;
    List<IncidentReport> incidentReports;

    @Override
    protected void init(VaadinRequest request) {
       // initData();
        orderForm = new OrderForm(incidentReportRepository, employeeRepository, incidentRepository, this);

        HorizontalLayout mainLayout = new HorizontalLayout();
        VerticalLayout orderLayout = new VerticalLayout();
        Button addIncident = new Button("Add incident templete");
        addIncident.setId("orderButton");
        addIncident.addClickListener(e -> {
            orderForm.setVisible(!orderForm.isVisible());
        });
        orderLayout.addComponents(addIncident, orderForm);
        mainLayout.addComponents(incidentReportGrid, orderLayout);

        setContent(mainLayout);
    }

    public void updateGrid() {
         incidentReports = (List<IncidentReport>) incidentReportRepository.findAll();
        incidentReportGrid.setItems(incidentReports);
         incidentReportGrid.removeAllColumns();
//         incidentReportGrid.addColumn(IncidentReport::getIncidentType).setCaption("Incident Type");
//         incidentReportGrid.addColumn(IncidentReport::getIncidentDate).setCaption("Incident Date");
//         incidentReportGrid.addColumn(IncidentReport::getIncidentDescr).setCaption("Incident Description");
//         incidentReportGrid.addColumn(IncidentReport::getEmployeeName).setCaption("Admin name");
//         incidentReportGrid.addColumn(IncidentReport::getEmployeeRole).setCaption("Admin role");
         
         
    }

    private void initData() {
//
//        IncidentReport incidentReport1 = new IncidentReport(new Employee("Michal Piotrowski", "Admin"), new Incident("Emergency"));
//        IncidentReport incidentReport2 = new IncidentReport(new Employee("Tomasz Skunkowski", "WebAdmin"), new Incident("NormalActivity"));
//        IncidentReport incidentReport3 = new IncidentReport(new Employee("Robert Giza", "NetAdmin"), new Incident("NotImportant"));
//        incidentReportRepository.save(incidentReport1);
//        incidentReportRepository.save(incidentReport2);
//        incidentReportRepository.save(incidentReport3);
        
        updateGrid();
    }

}
