/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spring.postgresql.asi.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import spring.postgresql.asi.model.ItSystem;
import spring.postgresql.asi.repo.ItSystemRepository;

/**
 *
 * @author Informatyka
 */
@RestController
public class ItSystemController {

    @Autowired
    ItSystemRepository repository;
    
    @GetMapping("/itsystems")
    public List<ItSystem> findSystems() {
        return (List<ItSystem>) repository.findAll();
    }
    
    @GetMapping("/itsystems/adminId={adminId}")
    public List<ItSystem> findSystemsByAdminId(@PathVariable("adminId") String adminId) {
        return (List<ItSystem>) repository.findByAdminId(adminId);
    }
}
