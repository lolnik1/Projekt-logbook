/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spring.postgresql.asi.model;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Informatyka
 */
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "systems")
public class ItSystem {

    @Id
    @NotNull
    private String id;

  //  @NotNull
    @Column(name = "name")
    private String name;

  //  @NotNull
    @Column(name = "descr")
    private String descr;

  //  @NotNull
    @Column(name = "adminId")
    private String adminId;

    @JsonIgnore
    @JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
    @OneToMany(mappedBy = "itSystem", cascade = CascadeType.ALL)
    private List<IncidentReport> incidentReport;

    public ItSystem(String id) {
    }

    public ItSystem(String id, String name, String descr, String adminId) {
        this.id = id;
        this.name = name;
        this.descr = descr;
        this.adminId = adminId;
    }

}
