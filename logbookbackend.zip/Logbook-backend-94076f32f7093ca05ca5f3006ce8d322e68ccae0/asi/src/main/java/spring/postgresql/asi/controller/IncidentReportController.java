/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spring.postgresql.asi.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import spring.postgresql.asi.model.Incident;
import spring.postgresql.asi.model.IncidentReport;
import spring.postgresql.asi.model.Employee;
import spring.postgresql.asi.model.ItSystem;
import spring.postgresql.asi.repo.EmployeeRepository;
import spring.postgresql.asi.repo.IncidentReportRepository;
import spring.postgresql.asi.repo.IncidentRepository;
import spring.postgresql.asi.repo.ItSystemRepository;
import spring.postgresql.asi.requests.AddIncidentRequest;
import spring.postgresql.asi.requests.AddTempleteIncidentRequest;

/**
 *
 * @author Informatyka
 */
@RestController
public class IncidentReportController {

    @Autowired
    IncidentReportRepository repository;
    @Autowired
    EmployeeRepository employeeRepository;
    @Autowired
    IncidentRepository incidentRepository;
    @Autowired
    ItSystemRepository itSystemRepository;

    @PostMapping("/incident/report")
    public IncidentReport saveIncident(@RequestBody AddIncidentRequest data) {
        IncidentReport incidentReport = new IncidentReport(data.getDate(), getEmployee(data.getEmployeeId()), data.getIncident(), getItSystem(data.getItSystemId()));
        repository.save(incidentReport);
        return incidentReport;
    }

    @PostMapping("/incident/report/template")
    public IncidentReport saveTempleteIncident(@RequestBody AddTempleteIncidentRequest data) {
        IncidentReport incidentReport = new IncidentReport(data.getDate(), getEmployee(data.getEmployeeId()), getIncident(data.getIncidentId()), getItSystem(data.getSystemId()));
        repository.save(incidentReport);
        return incidentReport;
    }

    @GetMapping("/incident/reports")
    public List<IncidentReport> getIncidentReports() {
        return (List<IncidentReport>) repository.findAll();
    }

    @GetMapping("/incident/report/ids")
    public List<Long> getReportIds() {
        List<Long> idList = new ArrayList<>();
        List<IncidentReport> reportList = (List<IncidentReport>) repository.findAll();
        for (int i = 0; i < reportList.size(); i++) {
            idList.add(reportList.get(i).getId());
        }
        return idList;
    }

    @GetMapping("/incident/reports/system={systemId}")
    public List<IncidentReport> getSystemReports(@PathVariable("systemId") String systemId) {
        List<IncidentReport> list = (List<IncidentReport>) repository.findAll();
        return list.stream()
                .distinct()
                .filter(incident -> Objects.equals(systemId, incident.getItSystem().getId()))
                .collect(Collectors.toList());
    }

    @GetMapping("/incident/reports/employeeId={employeeId}")
    public List<IncidentReport> getEmployeeReports(@PathVariable("employeeId") String employeeId) {
        List<IncidentReport> list = (List<IncidentReport>) repository.findAll();
        return list.stream()
                .distinct()
                .filter(incident -> Objects.equals(employeeId, incident.getEmployee().getId()))
                .collect(Collectors.toList());
    }
    
//    @GetMapping("/incident/reports/search/term={term}")
//    public List<IncidentReport> searchIncidentReportsByTerm(@PathVariable("term") String term) {
//        List<IncidentReport> list = (List<IncidentReport>) repository.findAll();
//        return list.stream()
//                .distinct()
//                .filter(incident -> Objects.equals(term, incident.getIncident().getDescr()))
//                .collect(Collectors.toList());
//    }
//
//    @GetMapping("/incident/reports/search/type={type}")
//    public List<IncidentReport> searchIncidentReportsByType(@PathVariable("type") String type) {
//        List<IncidentReport> list = (List<IncidentReport>) repository.findAll();
//        return list.stream()
//                .distinct()
//                .filter(incident -> Objects.equals(type, incident.getIncident().getType()))
//                .collect(Collectors.toList());
//    }
    @GetMapping("/incident/reports/search/term={term}")
    public List<IncidentReport> searchIncidentReportsByTerm(@PathVariable("term") String term) {
        List<IncidentReport> list = (List<IncidentReport>) repository.findAll();
        return list.stream()
                .distinct()
                .filter(incident -> incident.getIncident().getDescr().startsWith(term))
                .collect(Collectors.toList());
    }

    @GetMapping("/incident/reports/system={systemId}/search/type={type}")
    public List<IncidentReport> searchIncidentReportsByType(@PathVariable("systemId") String systemId, @PathVariable("type") String type) {
        List<IncidentReport> list = (List<IncidentReport>) repository.findAll();
        if (type == null || type.isEmpty()) {
            return list.stream().filter(incident -> Objects.equals(systemId, incident.getItSystem().getId())).collect(Collectors.toList());
        }
        return list.stream()
                .distinct()
                .filter(incident -> Objects.equals(systemId, incident.getItSystem().getId()))
                .filter(incident -> incident.getIncident().getType().toLowerCase().contains(type))
                .collect(Collectors.toList());
    }

    @GetMapping("/incident/report/id={id}")
    public IncidentReport findById(@PathVariable("id") long id) {
        return repository.findOne(id);
    }

    private Employee getEmployee(String id) {
        return employeeRepository.findById(id);
    }

    private Incident getIncident(Long id) {
        return incidentRepository.findOne(id);
    }

    private ItSystem getItSystem(String id) {
        return itSystemRepository.findById(id);
    }
}
