/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spring.postgresql.asi.model;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import java.sql.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "incidentReport")
public class IncidentReport {

    @Id
    @GeneratedValue
    private Long id;
    
    @Column(name = "date")
  // @Temporal(TemporalType.TIMESTAMP)
  //  @NotNull
    private Date addDate;
   
    @JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "employee_id")
    @NotNull
    private Employee employee;

    @JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "incident_id ")
    @NotNull
    private Incident incident;

     @JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "itsystem_id ")
    @NotNull
    private ItSystem itSystem;
    
    @JsonIgnore
    @JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
    @OneToMany(mappedBy = "incidentReport", cascade = CascadeType.ALL)
    private List<Comment> comments;
    
    
    
    
    public IncidentReport(Employee employee, Incident incident, ItSystem itSystem) {
        this.employee = employee;
        this.incident = incident;
        this.itSystem = itSystem;
        
    }

    public IncidentReport(Date addDate, Employee employee, Incident incident, ItSystem itSystem) {
        this.addDate = addDate;
        this.employee = employee;
        this.incident = incident;
        this.itSystem = itSystem;
    }

    
    
    public IncidentReport() {

    }


    @Override
    public String toString() {
        return "IncidentReport{" + "id=" + id + ", admin:" + employee + ", incident type=" + incident.getType() + ", incident desciption: " + incident.getDescr() + '}';
    }
}
