/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spring.postgresql.asi.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import spring.postgresql.asi.model.Comment;
import spring.postgresql.asi.model.IncidentReport;
import spring.postgresql.asi.repo.CommentRepository;
import spring.postgresql.asi.repo.IncidentReportRepository;
import spring.postgresql.asi.requests.AddComment;

/**
 *
 * @author Informatyka
 */
@RestController
public class CommentController {
    
    @Autowired
    CommentRepository commentRepository;
    @Autowired
    IncidentReportRepository incidentReportRepository;
    
    @GetMapping("/incident/report/id={incidentReportId}/comments")
    public List<Comment> findCommentsByIncidentReportId(@PathVariable("incidentReportId") Long incidentReportId) {
        return (List<Comment>) commentRepository.findByIncidentReportId(incidentReportId);
    }
    
    @PostMapping("/incident/report/id={incidentReportId}/comment")
    public Comment commentIncidentReport(@PathVariable("incidentReportId") Long incidentReportId, @RequestBody AddComment data) {
        Comment comment = new Comment(data.getDescr(), data.getDate(), getIncidentReport(incidentReportId));
        commentRepository.save(comment);
        return comment;
    }
    
    private IncidentReport getIncidentReport(Long id) {
        return incidentReportRepository.findOne(id);
    }
}
