/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spring.postgresql.asi.model;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Informatyka
 */
@Getter
@Entity
@Setter
@Table(name = "employees")
public class Employee implements Serializable {

    private static final long serialVersionUID = -3009157732242241606L;
    @JsonProperty("id")
    @Id
   // @GeneratedValue(generator = "system-uuid")
   // @GenericGenerator(name = "system-uuid", strategy = "uuid")
    //@GeneratedValue(strategy = GenerationType.AUTO)
    private String id;

    @JsonProperty("name")
    @Column(name = "name")
    private String name;

    @JsonProperty("role")
    @Column(name = "role")
    private String role;

    @Column(name = "email")
    private String email;
    
     @Column(name = "login")
    private String login;
     

     @JsonIgnore
    @Column(name = "isAsi")
    private boolean isAsi;
   

    @JsonIgnore
    @JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
    @OneToMany(mappedBy = "employee", cascade = CascadeType.ALL)
    private List<IncidentReport> incidentReport;

    public Employee() {
    }

    public Employee(String name, String role) {
        this.name = name;
        this.role = role;
    }

    public Employee(String name, String role, String email, boolean isAsi) {
        this.name = name;
        this.role = role;
        this.email = email;
        this.isAsi = isAsi;
    }

    public Employee(String id, String name, String role, String email, String login, boolean isAsi) {
        this.id = id;
        this.name = name;
        this.role = role;
        this.email = email;
        this.login = login;
        this.isAsi = isAsi;
    }

    @Override
    public String toString() {
        return String.format("%s, %s", name, role);
    }
}
